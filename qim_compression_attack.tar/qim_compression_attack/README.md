﻿11 - Thực hành kiểm tra QIM sau nén lại và lượng tử hóa lại hệ số DCT

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
