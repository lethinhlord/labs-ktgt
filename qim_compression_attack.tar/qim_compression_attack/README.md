Huong dan chi tiet duoc mo bang Firefox khi khoi dong lab. Terminal chi dung de thuc hien lenh thuc hanh.
