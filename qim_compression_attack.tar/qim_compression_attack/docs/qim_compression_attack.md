﻿11 - Thực hành kiểm tra QIM sau nén lại và lượng tử hóa lại hệ số DCT

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
