# 11 - Thực hành kiểm tra QIM sau nén lại và lượng tử hóa lại hệ số DCT

11 - Thực hành kiểm tra QIM sau nén lại và lượng tử hóa lại hệ số DCT

MỤC TIÊU
Mô phỏng tấn công nén lại: so sánh hệ số tần số thấp với hệ số tần số cao để thấy vì sao mục 4.2.2 ưu tiên vùng trung gian thấp.

VIDEO MẪU ĐI KÈM
- File: media/sample_video.mp4
- Mục đích: dữ liệu MP4 mẫu để bám chủ đề video chất lượng cao, DCT, QIM và ST-QIM.

HƯỚNG DẪN HTML
- File: guide.html
- Khi vào lab, hệ thống sẽ cố gắng mở guide.html. Nếu môi trường Labtainer không có trình duyệt GUI, chạy:
  python3 show_guide.py
  hoặc mở thủ công /home/ubuntu/lab/guide.html

CƠ SỞ LÝ THUYẾT
- Giáo trình mục 4.2.2: chọn khung, giải nén một phần, VLD/VLC, lượng tử hóa, DCT, QIM, biến đổi ngược và mã hóa lại video.
- Báo cáo ST-QIM: DCT 8x8, QIM/ST-QIM, packet MAGIC-length-CRC, PSNR, SSIM, BER, lặp frame và kiểm tra sau nén/noise/resize/drop.

QUY TRÌNH THỰC HÀNH TUẦN TỰ

Bước 1. Kiểm tra video mẫu và tách frame/audio
Lệnh:
  mkdir -p work
  pwd
  ls -lh input.mp4 media/sample_video.mp4 message.txt
  ls -lh media/sample_video.mp4
  sha256sum media/sample_video.mp4 | tee work/video_sha256.txt
  python3 extract_frames_audio.py
  xdg-open media/sample_video.mp4 || ffplay -autoexit media/sample_video.mp4
Mục đích:
  Xác nhận lab có video MP4 và tách frame/audio bằng ffmpeg.
Kết quả mong đợi:
  Terminal hiển thị kích thước file, SHA-256, Extracting Frames: 100% và trạng thái audio.

Bước 2. Chuẩn bị payload, bit, delta, khóa và hệ số DCT/ST-QIM
Lệnh:
  python3 run_lab.py prepare | tee work/prepare.log
Mục đích:
  Ghi nhận tham số đầu vào để tái lập.
Kết quả mong đợi:
  Terminal hiển thị bitstream, delta, seed/khóa và tham số thuật toán đã chuẩn bị.

Bước 3. Thực hiện nhúng hoặc mô phỏng nhúng QIM/ST-QIM
Lệnh:
  python3 frame_steganography_qim.py
Mục đích:
  Chạy thuật toán nhúng QIM/ST-QIM.
Kết quả mong đợi:
  Terminal hiển thị payload đã chuẩn bị và thông báo Embedding message with QIM/ST-QIM checked implementation.

Bước 4. Tách tin và đo chất lượng/độ bền
Lệnh:
  python3 combine_stego_frames_audio.py
Mục đích:
  Tính BER, CRC, PSNR/SSIM hoặc chỉ số attack theo bài.
Kết quả mong đợi:
  Terminal hiển thị decoded message, BER/CRC/chất lượng và Combined video saved to output/combined_video.mp4.

B??c 5. Xem video tr??c v? sau khi gi?u tin tr??c checkwork
Lệnh:
  ls -lh output/combined_video.mp4
  ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate -of default=noprint_wrappers=1 output/combined_video.mp4
  xdg-open output/combined_video.mp4 || ffplay -autoexit output/combined_video.mp4
Mục đích:
  Xác nhận điều kiện thuật toán đạt.
Kết quả mong đợi:
  Terminal hi?n th? th?ng tin video ??u ra v? m? ???c video sau khi gi?u tin b?ng xdg-open ho?c ffplay; video ph?i ph?t b?nh th??ng, kh?ng m?o ho?c v? khung h?nh.

Chấm bài:
  checkwork
Ch?y tr?n terminal Labtainer VM/host. K?t qu? ??t khi Labtainer x?c nh?n b?i l?m ho?n th?nh, kh?ng b?o l?i ho?c m?c ch?a ??t.

LỆNH LABTAINER
  imodule https://github.com/lethinhlord/labs-ktgt/qim_compression_attack.tar
  labtainer -r qim_compression_attack
  Nhập mã sinh viên khi Labtainer yêu cầu rồi ấn Enter.
  checkwork
  stoplab qim_compression_attack
