#!/bin/bash
# Standard Labtainer pregrade hook for QIM/ST-QIM labs.
# Copies current lab artifacts into .local/result before results.config is evaluated.
set -u
homedir=${1:-}
destdir=${2:-}
if [ -z "$homedir" ] || [ -z "$destdir" ] || [ ! -d "$homedir/$destdir" ]; then
  exit 0
fi
base="$homedir/$destdir"
result="$base/.local/result"
labdir="$base/lab"
mkdir -p "$result"

copy_file() {
  src="$1"
  [ -f "$src" ] || return 0
  cp "$src" "$result/$(basename "$src")" 2>/dev/null || true
}

if [ -d "$labdir/work" ]; then
  find "$labdir/work" -maxdepth 1 -type f \( -name '*.out' -o -name '*.json' -o -name '*.txt' \) | while IFS= read -r artifact; do
    copy_file "$artifact"
  done
fi
exit 0
