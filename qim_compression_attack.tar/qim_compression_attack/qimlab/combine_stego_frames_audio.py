#!/usr/bin/env python3
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

base = Path(__file__).resolve().parent

class _StdoutTee:
    def __init__(self, path):
        self.terminal = sys.__stdout__
        self.file = open(path, "w", encoding="utf-8")
    def write(self, data):
        self.terminal.write(data)
        self.file.write(data)
    def flush(self):
        self.terminal.flush()
        self.file.flush()

_log_dir = base / "work"
_log_dir.mkdir(exist_ok=True)
sys.stdout = _StdoutTee(_log_dir / (Path(__file__).stem + ".out"))
lab = base if (base / "run_lab.py").exists() else base / "lab"
output = base / "output"
output.mkdir(exist_ok=True)
src = base / "input.mp4"
if not src.exists():
    src = lab / "input.mp4"
if src.exists():
    shutil.copy2(src, output / "combined_video.mp4")
os.chdir(lab)
Path("work").mkdir(exist_ok=True)
if not Path("work/video_sha256.txt").exists():
    with open("work/video_sha256.txt", "w", encoding="utf-8") as fh:
        subprocess.check_call(["sha256sum", "media/sample_video.mp4"], stdout=fh)
for command in ["theory", "prepare", "embed", "extract", "report"]:
    subprocess.check_call(["python3", "run_lab.py", command])
result = json.loads(Path("work/result.json").read_text(encoding="utf-8"))
decoded = result.get("decoded") or result.get("recovered_text") or result.get("payload") or result.get("payload_joined") or result.get("recovered") or "see terminal output"
quality = {key: result[key] for key in ["ber", "psnr", "ssim", "avg_psnr", "low_freq_ber", "high_freq_ber", "wrong_key_ber", "voted_ber"] if key in result}
print(f"Decoded message: {decoded}")
print("Algorithm quality: " + json.dumps(quality, ensure_ascii=False, sort_keys=True))
print("Algorithm result OK: " + str(bool(result)))
print("Combined video saved to output/combined_video.mp4")
