#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

base = Path(__file__).resolve().parent

class _StdoutTee:
    def __init__(self, path):
        self.terminal = sys.__stdout__
        self.file = open(path, "w", encoding="utf-8")
    def write(self, data):
        self.terminal.write(data)
        self.file.write(data)
    def flush(self):
        self.terminal.flush()
        self.file.flush()

_log_dir = base / "work"
_log_dir.mkdir(exist_ok=True)
sys.stdout = _StdoutTee(_log_dir / (Path(__file__).stem + ".out"))
input_video = base / "input.mp4"
if not input_video.exists() and (base / "lab/input.mp4").exists():
    base = base / "lab"
    input_video = base / "input.mp4"
output = base / "output"
(output / "frames").mkdir(parents=True, exist_ok=True)
subprocess.check_call(["ffmpeg", "-y", "-v", "error", "-i", str(input_video), "-vf", "fps=1", str(output / "frames/frame_%04d.png")])
try:
    subprocess.check_call(["ffmpeg", "-y", "-v", "error", "-i", str(input_video), "-vn", "-acodec", "pcm_s16le", str(output / "audio.wav")])
    print("audio status: saved to output/audio.wav")
except subprocess.CalledProcessError:
    print("No audio stream found; continuing with video-only sample")
frame_count = len(list((output / "frames").glob("frame_*.png")))
print(f"Extracted frame files: {frame_count}")
print("Extracting Frames: 100%")
