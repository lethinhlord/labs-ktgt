#!/usr/bin/env python3
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path


def _safe_lab_name() -> str:
    lab_name = os.environ.get("LAB_NAME") or os.environ.get("HOSTNAME") or "qimlab"
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in lab_name)


def _process_uses_profile(profile: Path) -> bool:
    marker = str(profile)
    proc = Path("/proc")
    if not proc.exists():
        return False
    for cmdline in proc.glob("[0-9]*/cmdline"):
        try:
            text = cmdline.read_bytes().replace(b"\0", b" ").decode("utf-8", "ignore")
        except OSError:
            continue
        if "firefox" in text and marker in text:
            return True
    return False


def _rerun_as_lab_user(profile: Path, lock: Path) -> bool:
    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        return False
    if _process_uses_profile(profile):
        return True
    try:
        if profile.exists():
            shutil.rmtree(profile, ignore_errors=True)
        lock.unlink(missing_ok=True)
    except OSError:
        pass
    env_args = []
    for key in ("DISPLAY", "XAUTHORITY", "LAB_NAME", "HOSTNAME"):
        value = os.environ.get(key)
        if value:
            env_args.append(f"{key}={value}")
    env_args.extend([
        "HOME=/home/ubuntu",
        "MOZ_ENABLE_WAYLAND=0",
        "MOZ_WEBRENDER=0",
        "LIBGL_ALWAYS_SOFTWARE=1",
        "GDK_BACKEND=x11",
    ])
    cmd = ["sudo", "-u", "ubuntu", "-H", "env", *env_args, sys.executable, str(Path(__file__).resolve())]
    try:
        os.execvp("sudo", cmd)
    except OSError:
        return True
    return True


def _write_firefox_prefs(profile: Path) -> None:
    profile.mkdir(parents=True, exist_ok=True)
    (profile / "user.js").write_text(
        "\n".join([
            'user_pref("browser.shell.checkDefaultBrowser", false);',
            'user_pref("browser.startup.homepage_override.mstone", "ignore");',
            'user_pref("browser.aboutConfig.showWarning", false);',
            'user_pref("browser.translations.enable", false);',
            'user_pref("browser.translations.automaticallyPopup", false);',
            'user_pref("browser.translations.panelShown", true);',
            'user_pref("browser.translation.detectLanguage", false);',
            'user_pref("datareporting.policy.dataSubmissionPolicyBypassNotification", true);',
            'user_pref("toolkit.telemetry.reportingpolicy.firstRun", false);',
            'user_pref("app.normandy.first_run", false);',
            'user_pref("trailhead.firstrun.didSeeAboutWelcome", true);',
            'user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.addons", false);',
            'user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.features", false);',
            'user_pref("layers.acceleration.disabled", true);',
            'user_pref("gfx.webrender.force-disabled", true);',
            'user_pref("gfx.webrender.software", false);',
            'user_pref("media.hardware-video-decoding.enabled", false);',
        ]) + "\n",
        encoding="utf-8",
    )


def _acquire_lock(lock: Path) -> int | None:
    try:
        return os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        try:
            if time.time() - lock.stat().st_mtime > 20:
                lock.unlink()
                return os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except OSError:
            pass
        return None


def main() -> int:
    guide = Path("/home/ubuntu/lab/guide.html")
    browser = shutil.which("firefox") or shutil.which("firefox-esr")
    if not guide.exists() or browser is None or not os.environ.get("DISPLAY"):
        return 0

    safe_name = _safe_lab_name()
    profile = Path("/tmp") / f"labtainer-firefox-{safe_name}"
    lock = Path("/tmp") / f"labtainer-firefox-{safe_name}.lock"

    if _rerun_as_lab_user(profile, lock):
        return 0
    if _process_uses_profile(profile):
        return 0
    fd = _acquire_lock(lock)
    if fd is None:
        return 0
    try:
        if _process_uses_profile(profile):
            return 0
        _write_firefox_prefs(profile)
        for lock_name in (".parentlock", "lock"):
            try:
                (profile / lock_name).unlink()
            except FileNotFoundError:
                pass
            except OSError:
                pass
        env = os.environ.copy()
        env.update({"MOZ_ENABLE_WAYLAND": "0", "MOZ_WEBRENDER": "0", "LIBGL_ALWAYS_SOFTWARE": "1", "GDK_BACKEND": "x11"})
        subprocess.Popen([browser, "--no-remote", "--new-instance", "--profile", str(profile), guide.resolve().as_uri()], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env)
        time.sleep(1.5)
        return 0
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            lock.unlink()
        except OSError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
