﻿02 - Thực hành giấu tin vào hệ số DCT 8x8 bằng QIM

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
