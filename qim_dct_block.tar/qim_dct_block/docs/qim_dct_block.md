﻿02 - Thực hành giấu tin vào hệ số DCT 8x8 bằng QIM

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
