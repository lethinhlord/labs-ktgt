﻿05 - Thực hành DCT toàn khung và QIM trên tần số trung gian thấp

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
