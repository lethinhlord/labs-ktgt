﻿05 - Thực hành DCT toàn khung và QIM trên tần số trung gian thấp

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
