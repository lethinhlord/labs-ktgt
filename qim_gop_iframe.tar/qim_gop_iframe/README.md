﻿03 - Thực hành lựa chọn khung I trong chuỗi GOP để giấu tin

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
