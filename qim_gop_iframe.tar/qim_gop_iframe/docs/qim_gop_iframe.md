﻿03 - Thực hành lựa chọn khung I trong chuỗi GOP để giấu tin

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
