﻿09 - Thực hành lặp packet và majority vote chống nhiễu, rơi frame

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
