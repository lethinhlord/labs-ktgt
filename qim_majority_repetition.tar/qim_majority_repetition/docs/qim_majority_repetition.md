﻿09 - Thực hành lặp packet và majority vote chống nhiễu, rơi frame

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
