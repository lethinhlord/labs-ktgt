# Labtainer interactive shell setup. Keep terminal clean; guide opens in Firefox.
export PS1='qim_majority_repetition@student:\w\$ '
export LAB_NAME='qim_majority_repetition'
cd /home/ubuntu/lab 2>/dev/null || cd /home/ubuntu
if [ -f /home/ubuntu/lab/guide.html ] && [ -z "${QIM_GUIDE_SHOWN:-}" ]; then
  export QIM_GUIDE_SHOWN=1
  if command -v python3 >/dev/null 2>&1; then
    (python3 /home/ubuntu/lab/show_guide.py >/dev/null 2>&1 &)
  fi
fi
