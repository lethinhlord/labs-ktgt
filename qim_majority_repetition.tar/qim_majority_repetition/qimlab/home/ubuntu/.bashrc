cd /home/ubuntu/lab
if [ -f guide.html ] && [ -z "${QIM_GUIDE_SHOWN:-}" ]; then
  export QIM_GUIDE_SHOWN=1
  if command -v firefox >/dev/null 2>&1; then
    (firefox "file:///home/ubuntu/lab/guide.html" >/dev/null 2>&1 &)
  elif command -v firefox-esr >/dev/null 2>&1; then
    (firefox-esr "file:///home/ubuntu/lab/guide.html" >/dev/null 2>&1 &)
  fi
fi
