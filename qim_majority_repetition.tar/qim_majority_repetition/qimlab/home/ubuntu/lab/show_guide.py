#!/usr/bin/env python3
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path


def main() -> int:
    guide = Path("/home/ubuntu/lab/guide.html")
    browser = shutil.which("firefox") or shutil.which("firefox-esr")
    if not guide.exists() or browser is None:
        return 0
    env = os.environ.copy()
    subprocess.Popen(
        [browser, guide.resolve().as_uri()],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
