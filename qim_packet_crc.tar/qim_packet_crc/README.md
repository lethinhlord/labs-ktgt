﻿08 - Thực hành đóng gói payload với MAGIC, length và CRC khi giấu tin

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
