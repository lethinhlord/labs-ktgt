﻿08 - Thực hành đóng gói payload với MAGIC, length và CRC khi giấu tin

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
