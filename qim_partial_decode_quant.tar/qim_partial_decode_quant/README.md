﻿04 - Thực hành giải nén một phần VLD, zigzag và lượng tử hóa ngược

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
