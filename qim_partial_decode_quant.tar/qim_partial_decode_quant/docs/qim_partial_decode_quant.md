﻿# 04 - Thá»±c hĂ nh giáº£i nĂ©n má»™t pháº§n VLD, zigzag vĂ  lÆ°á»£ng tá»­ hĂ³a ngÆ°á»£c

04 - Thá»±c hĂ nh giáº£i nĂ©n má»™t pháº§n VLD, zigzag vĂ  lÆ°á»£ng tá»­ hĂ³a ngÆ°á»£c

Má»¤C TIĂU
MĂ´ phá»ng VLD/RLE, zigzag, giáº£i lÆ°á»£ng tá»­ há»‡ sá»‘ DCT vĂ  nhĂºng má»™t bit báº±ng QIM trĂªn há»‡ sá»‘ AC.

VIDEO MáºªU ÄI KĂˆM
- File: media/sample_video.mp4
- Má»¥c Ä‘Ă­ch: dá»¯ liá»‡u MP4 máº«u Ä‘á»ƒ bĂ¡m chá»§ Ä‘á» video cháº¥t lÆ°á»£ng cao, DCT, QIM vĂ  ST-QIM.

HÆ¯á»NG DáºªN HTML
- File: guide.html
- Khi vĂ o lab, há»‡ thá»‘ng sáº½ cá»‘ gáº¯ng má»Ÿ guide.html. Náº¿u mĂ´i trÆ°á»ng Labtainer khĂ´ng cĂ³ trĂ¬nh duyá»‡t GUI, cháº¡y:
  python3 show_guide.py
  hoáº·c má»Ÿ thá»§ cĂ´ng /home/ubuntu/lab/guide.html

CÆ  Sá» LĂ THUYáº¾T
- GiĂ¡o trĂ¬nh má»¥c 4.2.2: chá»n khung, giáº£i nĂ©n má»™t pháº§n, VLD/VLC, lÆ°á»£ng tá»­ hĂ³a, DCT, QIM, biáº¿n Ä‘á»•i ngÆ°á»£c vĂ  mĂ£ hĂ³a láº¡i video.
- BĂ¡o cĂ¡o ST-QIM: DCT 8x8, QIM/ST-QIM, packet MAGIC-length-CRC, PSNR, SSIM, BER, láº·p frame vĂ  kiá»ƒm tra sau nĂ©n/noise/resize/drop.

QUY TRĂŒNH THá»°C HĂ€NH TUáº¦N Tá»°

BÆ°á»›c 1. Kiá»ƒm tra video máº«u vĂ  tĂ¡ch frame/audio
Lá»‡nh:
  mkdir -p work
  pwd
  ls -lh input.mp4 media/sample_video.mp4 message.txt
  ls -lh media/sample_video.mp4
  sha256sum media/sample_video.mp4 | tee work/video_sha256.txt
  python3 extract_frames_audio.py
  ffplay -autoexit media/sample_video.mp4
Má»¥c Ä‘Ă­ch:
  XĂ¡c nháº­n lab cĂ³ video MP4 vĂ  tĂ¡ch frame/audio báº±ng ffmpeg.
Káº¿t quáº£ mong Ä‘á»£i:
  Terminal hiá»ƒn thá»‹ kĂ­ch thÆ°á»›c file, SHA-256, Extracting Frames: 100% vĂ  tráº¡ng thĂ¡i audio.

BÆ°á»›c 2. Chuáº©n bá»‹ payload, bit, delta, khĂ³a vĂ  há»‡ sá»‘ DCT/ST-QIM
Lá»‡nh:
  python3 run_lab.py prepare | tee work/prepare.log
Má»¥c Ä‘Ă­ch:
  Ghi nháº­n tham sá»‘ Ä‘áº§u vĂ o Ä‘á»ƒ tĂ¡i láº­p.
Káº¿t quáº£ mong Ä‘á»£i:
  Terminal hiá»ƒn thá»‹ bitstream, delta, seed/khĂ³a vĂ  tham sá»‘ thuáº­t toĂ¡n Ä‘Ă£ chuáº©n bá»‹.

BÆ°á»›c 3. Thá»±c hiá»‡n nhĂºng hoáº·c mĂ´ phá»ng nhĂºng QIM/ST-QIM
Lá»‡nh:
  python3 frame_steganography_qim.py
Má»¥c Ä‘Ă­ch:
  Cháº¡y thuáº­t toĂ¡n nhĂºng QIM/ST-QIM.
Káº¿t quáº£ mong Ä‘á»£i:
  Terminal hiá»ƒn thá»‹ payload Ä‘Ă£ chuáº©n bá»‹ vĂ  thĂ´ng bĂ¡o Embedding message with QIM/ST-QIM checked implementation.

BÆ°á»›c 4. TĂ¡ch tin vĂ  Ä‘o cháº¥t lÆ°á»£ng/Ä‘á»™ bá»n
Lá»‡nh:
  python3 combine_stego_frames_audio.py
Má»¥c Ä‘Ă­ch:
  TĂ­nh BER, CRC, PSNR/SSIM hoáº·c chá»‰ sá»‘ attack theo bĂ i.
Káº¿t quáº£ mong Ä‘á»£i:
  Terminal hiá»ƒn thá»‹ decoded message, BER/CRC/cháº¥t lÆ°á»£ng vĂ  Combined video saved to output/combined_video.mp4.

Bước 5. Xem video trước và sau khi giấu tin trước checkwork
Lá»‡nh:
  ls -lh output/combined_video.mp4
  ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate -of default=noprint_wrappers=1 output/combined_video.mp4
  ffplay -autoexit output/combined_video.mp4
Má»¥c Ä‘Ă­ch:
  XĂ¡c nháº­n Ä‘iá»u kiá»‡n thuáº­t toĂ¡n Ä‘áº¡t.
Káº¿t quáº£ mong Ä‘á»£i:
  Terminal hiển thị thông tin video đầu ra và mở được video sau khi giấu tin bằng xdg-open hoặc ffplay; video phải phát bình thường, không méo hoặc vỡ khung hình.

Cháº¥m bĂ i:
  checkwork
Chạy trên terminal Labtainer VM/host. Kết quả đạt khi Labtainer xác nhận bài làm hoàn thành, không báo lỗi hoặc mục chưa đạt.

Lá»†NH LABTAINER
  imodule https://github.com/lethinhlord/labs-ktgt/qim_partial_decode_quant.tar
  labtainer -r qim_partial_decode_quant
  Nháº­p mĂ£ sinh viĂªn khi Labtainer yĂªu cáº§u rá»“i áº¥n Enter.
  checkwork
  stoplab qim_partial_decode_quant
