#!/bin/bash
# Standard Labtainer pregrade hook for QIM/ST-QIM labs.
# Copies current lab artifacts into both standard root and container result paths.
set -u
homedir=${1:-}
destdir=${2:-}
if [ -z "$homedir" ] || [ -z "$destdir" ] || [ ! -d "$homedir/$destdir" ]; then
  exit 0
fi
base="$homedir/$destdir"
student_case=${destdir%%/*}
student_root="$homedir/$student_case"
container_result="$base/.local/result"
root_result="$student_root/.local/result"
labdir="$base/lab"
mkdir -p "$container_result" "$root_result"

copy_to_results() {
  src="$1"
  [ -f "$src" ] || return 0
  name="$(basename "$src")"
  cp "$src" "$container_result/$name" 2>/dev/null || true
  cp "$src" "$root_result/$name" 2>/dev/null || true
}

copy_artifacts_from_dir() {
  srcdir="$1"
  [ -d "$srcdir" ] || return 0
  find "$srcdir" -maxdepth 1 -type f \( -name '*.out' -o -name '*.json' -o -name '*.txt' \) | while IFS= read -r artifact; do
    copy_to_results "$artifact"
  done
}

copy_artifacts_from_dir "$base/work"
copy_artifacts_from_dir "$labdir/work"
copy_artifacts_from_dir "$base/.local/result"
copy_artifacts_from_dir "$labdir/.local/result"
exit 0
