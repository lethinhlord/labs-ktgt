﻿10 - Thực hành đánh giá PSNR, SSIM, BER và dung lượng giấu tin QIM

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
