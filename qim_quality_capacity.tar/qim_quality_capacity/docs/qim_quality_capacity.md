﻿10 - Thực hành đánh giá PSNR, SSIM, BER và dung lượng giấu tin QIM

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
