﻿07 - Thực hành ST-QIM với vector trải sinh từ khóa bí mật

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
