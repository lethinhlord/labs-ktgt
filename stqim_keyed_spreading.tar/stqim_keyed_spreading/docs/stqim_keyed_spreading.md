﻿07 - Thực hành ST-QIM với vector trải sinh từ khóa bí mật

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
