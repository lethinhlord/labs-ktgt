# Labtainer interactive shell setup. Keep terminal clean; guide opens in Firefox.
export PS1='stqim_keyed_spreading@student:\w\$ '
cd /home/ubuntu/lab 2>/dev/null || cd /home/ubuntu
if [ -f /home/ubuntu/lab/guide.html ] && [ -z "${QIM_GUIDE_SHOWN:-}" ]; then
  export QIM_GUIDE_SHOWN=1
  if command -v firefox >/dev/null 2>&1; then
    (firefox "file:///home/ubuntu/lab/guide.html" >/dev/null 2>&1 &)
  elif command -v firefox-esr >/dev/null 2>&1; then
    (firefox-esr "file:///home/ubuntu/lab/guide.html" >/dev/null 2>&1 &)
  elif command -v xdg-open >/dev/null 2>&1; then
    (xdg-open "file:///home/ubuntu/lab/guide.html" >/dev/null 2>&1 &)
  fi
fi
