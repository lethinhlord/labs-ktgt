﻿06 - Thực hành Spread Transform QIM trên vector hệ số DCT

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
