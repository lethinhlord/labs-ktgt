﻿06 - Thực hành Spread Transform QIM trên vector hệ số DCT

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
