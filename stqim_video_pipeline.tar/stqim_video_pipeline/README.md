﻿12 - Thực hành pipeline giấu và tách tin video bằng ST-QIM

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
