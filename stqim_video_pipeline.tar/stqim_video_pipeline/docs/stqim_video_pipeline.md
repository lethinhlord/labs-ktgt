﻿12 - Thực hành pipeline giấu và tách tin video bằng ST-QIM

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
