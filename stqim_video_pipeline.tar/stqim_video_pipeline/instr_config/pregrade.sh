#!/bin/bash
: <<'END'
Labtainer pregrade hook for QIM/ST-QIM video labs.
This mirrors the standard lab-demo/video-stego-dct pregrade hook shape.
END
homedir=$1
destdir=$2
cd "$homedir/$destdir" || exit 0
mkdir -p .local/result
if [ -f lab/work/result.json ]; then
  cp lab/work/result.json .local/result/result.json
fi
if [ -f lab/grade.txt ]; then
  cp lab/grade.txt .local/result/grade.txt
fi
