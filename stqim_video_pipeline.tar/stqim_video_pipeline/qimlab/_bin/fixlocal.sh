#!/bin/bash
# Standard Labtainer fixlocal hook.
exit 0
