#!/usr/bin/env python3
from pathlib import Path
import subprocess

base = Path(__file__).resolve().parent
input_video = base / "input.mp4"
if not input_video.exists() and (base / "lab/input.mp4").exists():
    base = base / "lab"
    input_video = base / "input.mp4"
output = base / "output"
(output / "frames").mkdir(parents=True, exist_ok=True)
subprocess.check_call(["ffmpeg", "-y", "-v", "error", "-i", str(input_video), "-vf", "fps=1", str(output / "frames/frame_%04d.png")])
try:
    subprocess.check_call(["ffmpeg", "-y", "-v", "error", "-i", str(input_video), "-vn", "-acodec", "pcm_s16le", str(output / "audio.wav")])
    print("audio status: saved to output/audio.wav")
except subprocess.CalledProcessError:
    print("No audio stream found; continuing with video-only sample")
frame_count = len(list((output / "frames").glob("frame_*.png")))
print(f"Extracted frame files: {frame_count}")
print("Extracting Frames: 100%")
