#!/usr/bin/env python3
from pathlib import Path
import json
import os
import subprocess

base = Path(__file__).resolve().parent
lab = base if (base / "run_lab.py").exists() else base / "lab"
os.chdir(lab)
Path("work").mkdir(exist_ok=True)
with open("work/video_sha256.txt", "w", encoding="utf-8") as fh:
    subprocess.check_call(["sha256sum", "media/sample_video.mp4"], stdout=fh)
subprocess.check_call(["python3", "run_lab.py", "theory"])
subprocess.check_call(["python3", "run_lab.py", "prepare"])
subprocess.check_call(["python3", "run_lab.py", "embed"])
step2 = json.loads(Path("work/step2_chuan_bi_tham_so_va_du_lieu_nhi_phan.json").read_text(encoding="utf-8"))
step3 = json.loads(Path("work/step3_thuc_hien_nhung_qim_stqim.json").read_text(encoding="utf-8"))
summary = step3.get("embedding_summary", {})
bits = summary.get("bits") or summary.get("packet_bits") or summary.get("payload_joined") or summary.get("written") or summary.get("frames") or []
bit_count = bits if isinstance(bits, int) else len(bits)
print(f"Prepared payload bits: {bit_count}")
print("Prepared algorithm keys: " + ", ".join(step2.get("result_keys", [])))
print("Embedding summary: " + json.dumps(summary, ensure_ascii=False, sort_keys=True))
print("Embedding message with QIM/ST-QIM checked implementation")
