#!/usr/bin/env python3
from __future__ import annotations

import argparse
import binascii
import hashlib
import json
import math
import random
import sys
from pathlib import Path

LAB_ID = "qim_scalar"
LAB_TITLE = "01 - Thực hành giấu và tách bit bằng thuật toán QIM vô hướng"
LAB_KIND = "scalar"
WORK = Path("work")
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

MID_COEFFS = [(1, 2), (2, 1), (2, 2), (1, 3), (3, 1), (2, 3)]
LOW_COEFFS = [(0, 1), (1, 0), (1, 1), (0, 2), (2, 0), (3, 0)]
HIGH_COEFFS = [(4, 4), (5, 3), (3, 5), (6, 2), (2, 6), (5, 5)]


def bits_from_text(text):
    out = []
    for byte in text.encode("utf-8"):
        out.extend((byte >> shift) & 1 for shift in range(7, -1, -1))
    return out


def text_from_bits(bits):
    data = bytearray()
    for i in range(0, len(bits) - len(bits) % 8, 8):
        value = 0
        for bit in bits[i:i+8]:
            value = (value << 1) | int(bit)
        data.append(value)
    return data.decode("utf-8", errors="replace")


def packet_bits(message):
    payload = message.encode("utf-8")
    header = b"QIM1" + len(payload).to_bytes(2, "big") + binascii.crc32(payload).to_bytes(4, "big")
    return bits_from_bytes(header + payload)


def bits_from_bytes(data):
    out = []
    for byte in data:
        out.extend((byte >> shift) & 1 for shift in range(7, -1, -1))
    return out


def bytes_from_bits(bits):
    data = bytearray()
    for i in range(0, len(bits) - len(bits) % 8, 8):
        value = 0
        for bit in bits[i:i+8]:
            value = (value << 1) | int(bit)
        data.append(value)
    return bytes(data)


def parse_packet(bits):
    raw = bytes_from_bits(bits)
    if len(raw) < 10 or raw[:4] != b"QIM1":
        raise ValueError("invalid MAGIC")
    n = int.from_bytes(raw[4:6], "big")
    crc = int.from_bytes(raw[6:10], "big")
    payload = raw[10:10+n]
    if len(payload) != n:
        raise ValueError("truncated payload")
    if binascii.crc32(payload) != crc:
        raise ValueError("CRC mismatch")
    return payload.decode("utf-8")


def q0(value, delta):
    return round(value / delta) * delta


def q1(value, delta):
    return round((value - delta / 2.0) / delta) * delta + delta / 2.0


def qim_embed(value, bit, delta):
    return q1(value, delta) if bit else q0(value, delta)


def qim_extract(value, delta):
    return 1 if abs(value - q1(value, delta)) < abs(value - q0(value, delta)) else 0


def dct_matrix(n=8):
    rows = []
    for u in range(n):
        alpha = math.sqrt(1 / n) if u == 0 else math.sqrt(2 / n)
        rows.append([alpha * math.cos(((2 * x + 1) * u * math.pi) / (2 * n)) for x in range(n)])
    return rows

T = dct_matrix(8)


def matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]


def transpose(a):
    return [list(row) for row in zip(*a)]


def dct2(block):
    centered = [[block[y][x] - 128.0 for x in range(8)] for y in range(8)]
    return matmul(matmul(T, centered), transpose(T))


def idct2(coeff):
    rec = matmul(matmul(transpose(T), coeff), T)
    return [[max(0, min(255, int(round(rec[y][x] + 128.0)))) for x in range(8)] for y in range(8)]


def make_block(seed=7):
    return [[(64 + 3 * y + 5 * x + ((x * y + seed) % 17)) % 256 for x in range(8)] for y in range(8)]


def make_frame(width=16, height=16, seed=3):
    return [[(72 + 2 * y + 3 * x + ((x * y + seed) % 29)) % 256 for x in range(width)] for y in range(height)]


def blocks(frame):
    for by in range(0, len(frame), 8):
        for bx in range(0, len(frame[0]), 8):
            yield by, bx, [[frame[by+y][bx+x] for x in range(8)] for y in range(8)]


def put_block(frame, by, bx, block):
    for y in range(8):
        for x in range(8):
            frame[by+y][bx+x] = block[y][x]


def psnr(a, b):
    vals = [(a[y][x] - b[y][x]) ** 2 for y in range(len(a)) for x in range(len(a[0]))]
    mse = sum(vals) / len(vals)
    if mse == 0:
        return 99.0
    return 10 * math.log10((255 * 255) / mse)


def ssim_simple(a, b):
    xs = [a[y][x] for y in range(len(a)) for x in range(len(a[0]))]
    ys = [b[y][x] for y in range(len(b)) for x in range(len(b[0]))]
    ux = sum(xs) / len(xs); uy = sum(ys) / len(ys)
    vx = sum((x - ux) ** 2 for x in xs) / len(xs); vy = sum((y - uy) ** 2 for y in ys) / len(ys)
    cov = sum((x - ux) * (y - uy) for x, y in zip(xs, ys)) / len(xs)
    c1 = 6.5025; c2 = 58.5225
    return ((2 * ux * uy + c1) * (2 * cov + c2)) / ((ux * ux + uy * uy + c1) * (vx + vy + c2))


def keyed_unit_vector(key, label, n):
    digest = hashlib.sha256((key + "|" + str(label)).encode()).digest()
    rng = random.Random(int.from_bytes(digest[:8], "big"))
    vec = [rng.gauss(0, 1) for _ in range(n)]
    norm = math.sqrt(sum(v * v for v in vec))
    return [v / norm for v in vec]


def stqim_embed(vec, bit, key, label, delta):
    u = keyed_unit_vector(key, label, len(vec))
    z = sum(a * b for a, b in zip(vec, u))
    q = qim_embed(z, bit, delta)
    return [x + (q - z) * ui for x, ui in zip(vec, u)]


def stqim_extract(vec, key, label, delta):
    u = keyed_unit_vector(key, label, len(vec))
    z = sum(a * b for a, b in zip(vec, u))
    return qim_extract(z, delta)


def majority(rows):
    n = min(len(row) for row in rows)
    return [1 if sum(row[i] for row in rows) >= len(rows) / 2 else 0 for i in range(n)]


def bit_error_rate(a, b):
    n = min(len(a), len(b))
    if n == 0:
        return 1.0
    return sum(int(a[i] != b[i]) for i in range(n)) / n


def quant_attack_coeffs(coeff, qstep=7, high_drop=True):
    out = [row[:] for row in coeff]
    for y in range(8):
        for x in range(8):
            if high_drop and x + y >= 7:
                out[y][x] = 0.0
            else:
                out[y][x] = round(out[y][x] / qstep) * qstep
    return out


def embed_bits_in_frame(frame, bit_list, coeffs, delta, key="qim-key", st=False):
    out = [row[:] for row in frame]
    written = 0
    for by, bx, block in blocks(out):
        coeff = dct2(block)
        for coords in [coeffs]:
            if written >= len(bit_list):
                break
            if st:
                vec = [coeff[y][x] for y, x in coords]
                new_vec = stqim_embed(vec, bit_list[written], key, f"{by}:{bx}:{written}", delta)
                for (y, x), value in zip(coords, new_vec):
                    coeff[y][x] = value
            else:
                y, x = coords[written % len(coords)]
                coeff[y][x] = qim_embed(coeff[y][x], bit_list[written], delta)
            written += 1
        put_block(out, by, bx, idct2(coeff))
        if written >= len(bit_list):
            break
    return out, written


def extract_bits_from_frame(frame, count, coeffs, delta, key="qim-key", st=False):
    got = []
    for by, bx, block in blocks(frame):
        coeff = dct2(block)
        if len(got) >= count:
            break
        if st:
            vec = [coeff[y][x] for y, x in coeffs]
            got.append(stqim_extract(vec, key, f"{by}:{bx}:{len(got)}", delta))
        else:
            y, x = coeffs[len(got) % len(coeffs)]
            got.append(qim_extract(coeff[y][x], delta))
    return got[:count]


def run_case():
    if LAB_KIND == "scalar":
        bits = bits_from_text("QIM")[:12]
        values = [13.2 + 5.7 * i for i in range(len(bits))]
        watermarked = [qim_embed(v, b, 10) for v, b in zip(values, bits)]
        attacked = [v + (1.2 if i % 2 else -1.1) for i, v in enumerate(watermarked)]
        recovered = [qim_extract(v, 10) for v in attacked]
        return {"payload": "QIM", "bits": bits, "recovered": recovered, "ber": bit_error_rate(bits, recovered), "delta": 10}
    if LAB_KIND == "dct_block":
        bits = [1, 0, 1, 1]
        block = make_block()
        coeff = dct2(block)
        for bit, (y, x) in zip(bits, MID_COEFFS):
            coeff[y][x] = qim_embed(coeff[y][x], bit, 18)
        rec = idct2(coeff)
        coeff2 = dct2(rec)
        recovered = [qim_extract(coeff2[y][x], 18) for y, x in MID_COEFFS[:len(bits)]]
        return {"bits": bits, "recovered": recovered, "ber": bit_error_rate(bits, recovered), "psnr": psnr(block, rec), "coeffs": MID_COEFFS[:4]}
    if LAB_KIND == "gop":
        frames = [{"index": i, "type": "I" if i % 6 == 0 else ("P" if i % 2 == 0 else "B")} for i in range(18)]
        selected = [f for f in frames if f["type"] == "I"]
        payload_parts = ["101", "001", "111"]
        for f, part in zip(selected, payload_parts):
            f["payload"] = part
        return {"frame_types": [f["type"] for f in frames], "selected_indices": [f["index"] for f in selected], "only_i_frames": all(f["type"] == "I" for f in selected), "payload_joined": "".join(f.get("payload", "") for f in selected)}
    if LAB_KIND == "partial_decode":
        zigzag = [(0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0)]
        rle = [(0, 12), (1, -3), (0, 7), (2, 2), (0, 0)]
        q = 8
        coeff = [[0.0 for _ in range(8)] for _ in range(8)]
        pos = 0
        for run, level in rle:
            if level == 0:
                break
            pos += run
            y, x = zigzag[pos]
            coeff[y][x] = level * q
            pos += 1
        coeff[0][1] = qim_embed(coeff[0][1], 1, 16)
        bit = qim_extract(coeff[0][1], 16)
        return {"vld_tokens": rle, "inverse_quant_step": q, "embedded_bit": bit, "nonzero_coeffs": sum(1 for row in coeff for v in row if v != 0)}
    if LAB_KIND == "full_frame":
        frame = make_frame(16, 16)
        bits = bits_from_text("F")
        wm, written = embed_bits_in_frame(frame, bits, LOW_COEFFS, 20, st=False)
        recovered = extract_bits_from_frame(wm, len(bits), LOW_COEFFS, 20, st=False)
        return {"written": written, "ber": bit_error_rate(bits, recovered), "psnr": psnr(frame, wm), "ssim": ssim_simple(frame, wm), "coeff_policy": "low-mid frequency, avoid DC"}
    if LAB_KIND == "stqim":
        vec = [21.4, -8.2, 13.0, 5.5, -3.1, 7.7]
        bits = [1, 0, 1, 0]
        recovered = []
        for i, bit in enumerate(bits):
            y = stqim_embed(vec, bit, "secret", i, 14)
            recovered.append(stqim_extract(y, "secret", i, 14))
        return {"bits": bits, "recovered": recovered, "ber": bit_error_rate(bits, recovered), "vector_length": len(vec), "delta": 14}
    if LAB_KIND == "keyed":
        base_vec = [12.5, -4.0, 9.2, 6.3, -2.4, 3.9]
        bits = [1, 0, 1, 1, 0, 0, 1, 0]
        good = []
        bad = []
        for i, bit in enumerate(bits):
            vec = [v + 0.37 * i for v in base_vec]
            y = stqim_embed(vec, bit, "correct-key", f"lab07:{i}", 18)
            good.append(stqim_extract(y, "correct-key", f"lab07:{i}", 18))
            bad.append(stqim_extract(y, "wrong-key", f"lab07:{i}", 18))
        wrong_key_ber = bit_error_rate(bits, bad)
        return {"bits": bits, "correct_key_bits": good, "wrong_key_bits": bad, "wrong_key_ber": wrong_key_ber, "security_check": good == bits and wrong_key_ber >= 0.25, "key_hash_prefix": hashlib.sha256(b"correct-key").hexdigest()[:12]}
    if LAB_KIND == "packet":
        payload = "CRC_OK"
        bits = packet_bits(payload)
        decoded = parse_packet(bits)
        tampered = bits[:]
        tampered[-1] ^= 1
        try:
            parse_packet(tampered)
            crc_detected = False
        except ValueError:
            crc_detected = True
        return {"payload": payload, "decoded": decoded, "payload_match": decoded == payload, "crc_detected_tamper": crc_detected, "packet_bits": len(bits)}
    if LAB_KIND == "majority":
        payload_bits = bits_from_text("M")
        rows = []
        for r in range(5):
            row = payload_bits[:]
            if r in (1, 3):
                row[(r + 2) % len(row)] ^= 1
            rows.append(row)
        voted = majority(rows)
        return {"replicas": len(rows), "raw_row_ber": bit_error_rate(payload_bits, rows[1]), "voted_ber": bit_error_rate(payload_bits, voted), "recovered_text": text_from_bits(voted)}
    if LAB_KIND == "metrics":
        frame = make_frame(16, 16)
        bits = bits_from_text("Q")
        results = []
        for delta in (14, 28, 42):
            wm, _ = embed_bits_in_frame(frame, bits, LOW_COEFFS, delta, st=False)
            rec = extract_bits_from_frame(wm, len(bits), LOW_COEFFS, delta, st=False)
            results.append({"delta": delta, "psnr": round(psnr(frame, wm), 3), "ssim": round(ssim_simple(frame, wm), 5), "ber": bit_error_rate(bits, rec)})
        return {"results": results, "best_quality_delta": min(results, key=lambda r: -r["psnr"])["delta"], "all_clean_ber_zero": all(r["ber"] == 0 for r in results)}
    if LAB_KIND == "compression":
        bits = [1, 0, 1, 1, 0, 1]
        block = make_block(11)
        coeff_low = dct2(block)
        coeff_high = dct2(block)
        for bit, (y, x) in zip(bits, LOW_COEFFS):
            coeff_low[y][x] = qim_embed(coeff_low[y][x], bit, 24)
        for bit, (y, x) in zip(bits, HIGH_COEFFS):
            coeff_high[y][x] = qim_embed(coeff_high[y][x], bit, 24)
        low_att = quant_attack_coeffs(coeff_low, 6, high_drop=True)
        high_att = quant_attack_coeffs(coeff_high, 6, high_drop=True)
        low_rec = [qim_extract(low_att[y][x], 24) for y, x in LOW_COEFFS[:len(bits)]]
        high_rec = [qim_extract(high_att[y][x], 24) for y, x in HIGH_COEFFS[:len(bits)]]
        return {"low_freq_ber": bit_error_rate(bits, low_rec), "high_freq_ber": bit_error_rate(bits, high_rec), "low_survives_better": bit_error_rate(bits, low_rec) <= bit_error_rate(bits, high_rec)}
    if LAB_KIND == "end_to_end":
        payload = "N8"
        bits = packet_bits(payload)
        frames = [make_frame(80, 80, seed=i) for i in range(6)]
        watermarked = []
        observations = []
        for i, frame in enumerate(frames):
            wm, _ = embed_bits_in_frame(frame, bits, LOW_COEFFS, 38, key="end-key", st=True)
            if i == 2:
                attacked = [[max(0, min(255, v + (1 if (x + y) % 3 == 0 else -1))) for x, v in enumerate(row)] for y, row in enumerate(wm)]
            else:
                attacked = wm
            watermarked.append(attacked)
            observations.append(extract_bits_from_frame(attacked, len(bits), LOW_COEFFS, 38, key="end-key", st=True))
        decoded = parse_packet(majority(observations))
        return {"payload": payload, "decoded": decoded, "payload_match": decoded == payload, "frames": len(frames), "avg_psnr": sum(psnr(a,b) for a,b in zip(frames, watermarked)) / len(frames)}
    raise ValueError("unknown lab kind")


def expected_ok(result):
    kind = LAB_KIND
    if kind in {"scalar", "dct_block", "full_frame", "stqim"}:
        return result.get("ber") == 0
    if kind == "gop":
        return result.get("only_i_frames") is True and result.get("selected_indices") == [0, 6, 12]
    if kind == "partial_decode":
        return result.get("embedded_bit") == 1 and result.get("nonzero_coeffs", 0) >= 3
    if kind == "keyed":
        return result.get("security_check") is True
    if kind == "packet":
        return result.get("payload_match") is True and result.get("crc_detected_tamper") is True
    if kind == "majority":
        return result.get("voted_ber") == 0 and result.get("recovered_text") == "M"
    if kind == "metrics":
        return result.get("all_clean_ber_zero") is True
    if kind == "compression":
        return result.get("low_survives_better") is True and result.get("low_freq_ber") == 0
    if kind == "end_to_end":
        return result.get("payload_match") is True and result.get("avg_psnr", 0) > 30
    return False


def write_outputs(result):
    WORK.mkdir(exist_ok=True)
    (WORK / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        f"{LAB_ID} - {LAB_TITLE}",
        "Nguon ly thuyet: giao trinh muc 4.2.2 va bao cao ST-QIM.",
        f"Ket qua chinh: {json.dumps(result, ensure_ascii=False)}",
    ]
    (WORK / "summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


STEP_NAMES = {
    "1": "doc_co_so_ly_thuyet_va_video_mau",
    "2": "chuan_bi_tham_so_va_du_lieu_nhi_phan",
    "3": "thuc_hien_nhung_qim_stqim",
    "4": "tach_tin_va_do_chat_luong",
    "5": "kiem_tra_tong_hop_checkwork",
}


def step_payload(step, result):
    video_path = Path("media/sample_video.mp4")
    common = {
        "lab_id": LAB_ID,
        "lab_title": LAB_TITLE,
        "lab_kind": LAB_KIND,
        "video_sample": str(video_path),
        "video_sample_exists": video_path.exists(),
        "source_basis": "Giao trinh muc 4.2.2 va bao cao ST-QIM video",
    }
    if step == "1":
        return {**common, "purpose": "Doc muc tieu bai lab, kiem tra video MP4 mau va xac dinh quy trinh nen/DCT/QIM/ST-QIM se thuc hien.", "expected_result": "Sinh vien nam duoc vi tri file media/sample_video.mp4 va cac lenh se chay tuan tu."}
    if step == "2":
        return {**common, "purpose": "Chuan bi payload, bit, delta, khoa, he so DCT hoac vector ST-QIM phu hop voi bai lab.", "expected_result": "Du lieu dau vao va tham so nhung/tach duoc ghi nhan de co the tai lap.", "result_keys": sorted(result.keys())}
    if step == "3":
        return {**common, "purpose": "Thuc hien buoc nhung hoac mo phong nhung QIM/ST-QIM theo thuat toan cua bai.", "expected_result": "Tao duoc artifact trung gian the hien tin da duoc nhung vao he so/packet/frame.", "embedding_summary": result}
    if step == "4":
        return {**common, "purpose": "Tach tin, tinh BER/PSNR/SSIM/CRC hoac so sanh do ben sau tan cong tuy tung bai.", "expected_result": "Ket qua tach tin va chi so danh gia duoc ghi trong result.json.", "extraction_summary": result}
    if step == "5":
        return {**common, "purpose": "Kiem tra tong hop truoc khi chay checkwork.", "expected_result": "expected_ok phai bang true; sau do chay checkwork va nhap ma sinh vien.", "algorithm_ok": expected_ok(result)}
    raise ValueError("step must be one of 1, 2, 3, 4, 5, all")


def run_step(step):
    result = run_case()
    if step == "all":
        for item in ["1", "2", "3", "4", "5"]:
            run_step(item)
        write_outputs(result)
        return result
    payload = step_payload(step, result)
    WORK.mkdir(exist_ok=True)
    name = STEP_NAMES[step]
    out = WORK / f"step{step}_{name}.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (WORK / f"step{step}_{name}.txt").write_text(
        f"{LAB_TITLE}\nSTEP {step}: {name}\nMuc dich: {payload['purpose']}\nKet qua mong doi: {payload['expected_result']}\n",
        encoding="utf-8",
    )
    if step == "5":
        write_outputs(result)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    print(f"Da tao {out}")
    return payload


def grade(student_id=""):
    result_path = WORK / "result.json"
    if not result_path.exists():
        result = run_case()
        write_outputs(result)
    else:
        result = json.loads(result_path.read_text(encoding="utf-8"))
    student_id = (student_id or "").strip()
    video_path = Path("media/sample_video.mp4")
    video_ok = video_path.exists() and video_path.stat().st_size > 0
    student_ok = len(student_id) >= 3
    if student_ok:
        WORK.mkdir(exist_ok=True)
        (WORK / "student_id.txt").write_text(student_id + "\n", encoding="utf-8")
    ok = expected_ok(result) and student_ok and video_ok
    report = [
        f"LAB={LAB_ID}",
        f"TITLE={LAB_TITLE}",
        f"STUDENT_ID={student_id if student_ok else 'INVALID'}",
        f"VIDEO_SAMPLE={video_path if video_ok else 'MISSING'}",
        f"CHECK={ok}",
    ]
    report.append("ALL_CHECKS_PASSED" if ok else "CHECKS_FAILED")
    Path("grade.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0 if ok else 2


COMMAND_STEPS = {
    "theory": "1",
    "prepare": "2",
    "embed": "3",
    "extract": "4",
    "report": "5",
    "all": "all",
}


def main():
    parser = argparse.ArgumentParser(description=LAB_TITLE)
    parser.add_argument("command", nargs="?", choices=sorted(COMMAND_STEPS), default="all", help="Lenh thuc hanh: theory, prepare, embed, extract, report, all")
    parser.add_argument("--info", action="store_true", help="In thong tin lab")
    parser.add_argument("--step", default=None, help=argparse.SUPPRESS)
    parser.add_argument("--grade", action="store_true", help="Kiem tra ket qua lab")
    parser.add_argument("--student-id", default="", help="Ma sinh vien dung khi checkwork")
    args = parser.parse_args()
    if args.info:
        print(LAB_ID)
        print(LAB_TITLE)
        print("Thu muc lam viec: work/")
        return 0
    if args.grade:
        return grade(args.student_id)
    step = args.step if args.step is not None else COMMAND_STEPS[args.command]
    if step not in {"1", "2", "3", "4", "5", "all"}:
        raise SystemExit("command must be theory, prepare, embed, extract, report, or all")
    run_step(step)
    if step == "all":
        print("Da chay tat ca cac buoc va tao work/result.json, work/summary.txt. Chay: checkwork")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
