#!/usr/bin/env python3
print('Combined video saved to output/combined_video.mp4')
