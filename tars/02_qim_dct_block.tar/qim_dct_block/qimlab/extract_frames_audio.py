#!/usr/bin/env python3
from pathlib import Path
import subprocess
Path('output').mkdir(exist_ok=True)
subprocess.check_call(['ffmpeg','-y','-v','error','-i','input.mp4','-vf','fps=1','output/frame_%04d.png'])
print('Extracting Frames: 100%')
