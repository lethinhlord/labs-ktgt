#!/usr/bin/env python3
print('Embedding message with QIM/ST-QIM algorithm entry point')
print('Use lab/run_lab.py embed for the checked implementation')
