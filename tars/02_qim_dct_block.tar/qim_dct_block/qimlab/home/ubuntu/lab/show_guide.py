#!/usr/bin/env python3
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path


def main() -> int:
    guide = Path("/home/ubuntu/lab/guide.html")
    if not guide.exists():
        print("Khong tim thay guide.html trong /home/ubuntu/lab.")
        return 0
    uri = guide.resolve().as_uri()
    print(f"Huong dan HTML: {guide}")
    if os.environ.get("QIM_GUIDE_OPENED") == "1":
        return 0
    os.environ["QIM_GUIDE_OPENED"] = "1"
    for opener in ("xdg-open", "sensible-browser"):
        path = shutil.which(opener)
        if not path:
            continue
        try:
            subprocess.Popen([path, uri], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"Da gui lenh mo guide.html bang {opener}.")
            return 0
        except Exception:
            pass
    try:
        opened = webbrowser.open(uri, new=2)
    except Exception as exc:
        print(f"Khong the tu mo trinh duyet HTML: {exc}")
        return 0
    if opened:
        print("Da gui lenh mo huong dan HTML bang trinh duyet cua moi truong Labtainer.")
    else:
        print("Moi truong hien tai khong co trinh duyet GUI. Hay mo file guide.html neu can xem bang HTML.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
