cd /home/student/lab
if [ -f NOTE.txt ] && [ -z "${QIM_NOTE_SHOWN:-}" ]; then
  export QIM_NOTE_SHOWN=1
  cat NOTE.txt
fi
