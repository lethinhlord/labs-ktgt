#!/usr/bin/env python3
from pathlib import Path
import os, shutil, subprocess
home = Path(__file__).resolve().parent
Path(home / 'output').mkdir(exist_ok=True)
if (home / 'input.mp4').exists():
    shutil.copy2(home / 'input.mp4', home / 'output/combined_video.mp4')
os.chdir(home / 'lab')
Path('work').mkdir(exist_ok=True)
if not Path('work/video_sha256.txt').exists():
    with open('work/video_sha256.txt', 'w', encoding='utf-8') as fh:
        subprocess.check_call(['sha256sum','media/sample_video.mp4'], stdout=fh)
for command in ['theory','prepare','embed','extract','report']:
    subprocess.check_call(['python3','run_lab.py',command])
print('Combined video saved to output/combined_video.mp4')
