#!/usr/bin/env python3
from pathlib import Path
import subprocess
Path('output/frames').mkdir(parents=True, exist_ok=True)
subprocess.check_call(['ffmpeg','-y','-v','error','-i','input.mp4','-vf','fps=1','output/frames/frame_%04d.png'])
try:
    subprocess.check_call(['ffmpeg','-y','-v','error','-i','input.mp4','-vn','-acodec','pcm_s16le','output/audio.wav'])
    print('Audio saved to output/audio.wav')
except subprocess.CalledProcessError:
    print('No audio stream found; continuing with video-only sample')
print('Extracting Frames: 100%')
