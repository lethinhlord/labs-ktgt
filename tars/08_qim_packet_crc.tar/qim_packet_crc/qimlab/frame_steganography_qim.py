#!/usr/bin/env python3
from pathlib import Path
import os, subprocess
os.chdir(Path(__file__).resolve().parent / 'lab')
Path('work').mkdir(exist_ok=True)
with open('work/video_sha256.txt', 'w', encoding='utf-8') as fh:
    subprocess.check_call(['sha256sum','media/sample_video.mp4'], stdout=fh)
subprocess.check_call(['python3','run_lab.py','theory'])
subprocess.check_call(['python3','run_lab.py','prepare'])
subprocess.check_call(['python3','run_lab.py','embed'])
print('Embedding message with QIM/ST-QIM checked implementation')
