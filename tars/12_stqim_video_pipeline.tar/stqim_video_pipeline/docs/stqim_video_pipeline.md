# 12 - Thực hành pipeline giấu và tách tin video bằng ST-QIM

12 - Thực hành pipeline giấu và tách tin video bằng ST-QIM

MỤC TIÊU
Tích hợp pipeline: tách frame, DCT 8x8, ST-QIM, packet/CRC, lặp frame, majority vote và kiểm tra chất lượng sau nhiễu nhẹ.

VIDEO MẪU ĐI KÈM
- File: media/sample_video.mp4
- Mục đích: dữ liệu MP4 mẫu để bám chủ đề video chất lượng cao, DCT, QIM và ST-QIM.

HƯỚNG DẪN HTML
- File: guide.html
- Khi vào lab, hệ thống sẽ cố gắng mở guide.html. Nếu môi trường Labtainer không có trình duyệt GUI, chạy:
  python3 show_guide.py
  hoặc mở thủ công /home/student/lab/guide.html

CƠ SỞ LÝ THUYẾT
- Giáo trình mục 4.2.2: chọn khung, giải nén một phần, VLD/VLC, lượng tử hóa, DCT, QIM, biến đổi ngược và mã hóa lại video.
- Báo cáo ST-QIM: DCT 8x8, QIM/ST-QIM, packet MAGIC-length-CRC, PSNR, SSIM, BER, lặp frame và kiểm tra sau nén/noise/resize/drop.

QUY TRÌNH THỰC HÀNH TUẦN TỰ

Bước 1. Đọc cơ sở lý thuyết và kiểm tra video mẫu
Lệnh:
  python3 run_lab.py --step 1
Mục đích:
  Xác nhận lab có video MP4 và hiểu pipeline mục 4.2.2.
Kết quả mong đợi:
  Tạo work/step1_doc_co_so_ly_thuyet_va_video_mau.json

Bước 2. Chuẩn bị payload, bit, delta, khóa và hệ số DCT/ST-QIM
Lệnh:
  python3 run_lab.py --step 2
Mục đích:
  Ghi nhận tham số đầu vào để tái lập.
Kết quả mong đợi:
  Tạo work/step2_chuan_bi_tham_so_va_du_lieu_nhi_phan.json

Bước 3. Thực hiện nhúng hoặc mô phỏng nhúng QIM/ST-QIM
Lệnh:
  python3 run_lab.py --step 3
Mục đích:
  Tạo artifact trung gian thể hiện quá trình nhúng.
Kết quả mong đợi:
  Tạo work/step3_thuc_hien_nhung_qim_stqim.json

Bước 4. Tách tin và đo chất lượng/độ bền
Lệnh:
  python3 run_lab.py --step 4
Mục đích:
  Tính BER, CRC, PSNR/SSIM hoặc chỉ số attack theo bài.
Kết quả mong đợi:
  Tạo work/step4_tach_tin_va_do_chat_luong.json

Bước 5. Kiểm tra tổng hợp trước checkwork
Lệnh:
  python3 run_lab.py --step 5
Mục đích:
  Xác nhận điều kiện thuật toán đạt.
Kết quả mong đợi:
  Tạo work/step5_kiem_tra_tong_hop_checkwork.json, work/result.json và work/summary.txt

Chấm bài:
  checkwork
Khi được hỏi, nhập mã sinh viên của bạn. Checkwork sẽ lưu mã sinh viên vào work/student_id.txt.

LỆNH LABTAINER
  imodule file:///duong/dan/12_stqim_video_pipeline.tar
  labtainer stqim_video_pipeline -r
  moreterm.py stqim_video_pipeline qimlab
  checkwork
  stoplab
