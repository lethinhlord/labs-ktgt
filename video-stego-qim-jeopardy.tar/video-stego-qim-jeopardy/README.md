13 - Jeopardy QIM và ST-QIM trong giấu tin video

LÝ THUYẾT TÓM TẮT
QIM: Q0(x)=Δ·round(x/Δ); Q1(x)=Δ·round((x-Δ/2)/Δ)+Δ/2; bit tách được chọn theo tập lượng tử gần nhất.
DCT 8×8: ưu tiên hệ số AC thấp-trung bình, tránh hệ số DC F(0,0) để giảm méo cảm nhận.
ST-QIM: z=uᵀx, z'=Qb(z), y=x+(z'-z)u; vector u sinh từ khóa và có ||u||₂=1.

LỆNH LABTAINER
imodule https://github.com/lethinhlord/labs-ktgt/video-stego-qim-jeopardy.tar
labtainer -r video-stego-qim-jeopardy

QUY TRÌNH CHÍNH
1. Kiểm tra video MP4 mẫu
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate -of default=noprint_wrappers=1 media/sample_video.mp4
python3 jeopardy_lab.py probe
Kết quả cần đạt: Terminal hiển thị codec, độ phân giải, tốc độ khung hình và hash video thật.

2. Xem video trước khi giấu tin
xdg-open media/sample_video.mp4 || ffplay -autoexit media/sample_video.mp4
Kết quả cần đạt: Video gốc mở được, không báo lỗi định dạng.

3. Giải thử thách QIM vô hướng
python3 jeopardy_lab.py challenge1
Kết quả cần đạt: Terminal báo thử thách scalar QIM solved và in flag của thử thách.

4. Giải thử thách DCT-QIM
python3 jeopardy_lab.py challenge2
Kết quả cần đạt: Terminal hiển thị BER bằng 0 và chỉ số PSNR/SSIM đạt ngưỡng.

5. Giải thử thách ST-QIM có khóa
python3 jeopardy_lab.py challenge3
Kết quả cần đạt: Terminal báo correct-key BER bằng 0 và wrong-key BER cao hơn ngưỡng.

6. Tạo và xem video sau khi giấu tin
python3 jeopardy_lab.py render
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate -of default=noprint_wrappers=1 output/jeopardy_stego.mp4
xdg-open output/jeopardy_stego.mp4 || ffplay -autoexit output/jeopardy_stego.mp4
Kết quả cần đạt: Video sau nhúng mở được; terminal hiển thị PSNR/SSIM và xác nhận có cả QIM, ST-QIM.

7. Mở GUI Nhóm 8 và tổng hợp điểm
python3 gui_nhom8.py
python3 jeopardy_lab.py scoreboard
Kết quả cần đạt: GUI Nhóm 8 mở được; scoreboard báo hoàn thành 3/3 thử thách và chất lượng video đạt.

Sau khi hoàn thành, quay về terminal Labtainer VM/host và chạy: checkwork
Dừng lab: stoplab video-stego-qim-jeopardy
