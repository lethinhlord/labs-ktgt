13 - Jeopardy QIM và ST-QIM trong giấu tin video

BỐI CẢNH CTF
Đội phân tích nhận được một video MP4 nghi vấn từ kho bằng chứng. Dấu vết lượng tử trong miền DCT cho thấy dữ liệu có thể đã được giấu bằng QIM và ST-QIM.
Nhiệm vụ: đi qua từng stage, khôi phục flag, chứng minh vai trò của khóa ST-QIM và dựng video sau nhúng để so sánh chất lượng.

LÝ THUYẾT TÓM TẮT
QIM: Q0(x)=Δ·round(x/Δ); Q1(x)=Δ·round((x-Δ/2)/Δ)+Δ/2; bit tách được chọn theo tập lượng tử gần nhất.
DCT 8×8: ưu tiên hệ số AC thấp-trung bình, tránh hệ số DC F(0,0) để giảm méo cảm nhận.
ST-QIM: z=uᵀx, z'=Qb(z), y=x+(z'-z)u; vector u sinh từ khóa và có ||u||₂=1.

LỆNH LABTAINER
imodule https://github.com/lethinhlord/labs-ktgt/video-stego-qim-jeopardy.tar
labtainer -r video-stego-qim-jeopardy

QUY TRÌNH CHÍNH
1. Stage 01 - Xác nhận vị trí làm bài
pwd
Kết quả cần đạt: Terminal hiển thị đường dẫn /home/ubuntu/lab.

2. Stage 02 - Liệt kê tệp lab
ls -lh
Kết quả cần đạt: Terminal hiển thị các tệp hướng dẫn, GUI, video và mã thuật toán của bài lab.

3. Stage 03 - Kiểm tra video mẫu
ls -lh media/sample_video.mp4
Kết quả cần đạt: Terminal hiển thị tệp media/sample_video.mp4 với dung lượng hợp lệ.

4. Stage 04 - Đọc metadata video gốc
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate -of default=noprint_wrappers=1 media/sample_video.mp4
Kết quả cần đạt: Terminal hiển thị codec, độ phân giải và tốc độ khung hình của video gốc.

5. Stage 05 - Tính dấu vết video gốc
sha256sum media/sample_video.mp4
Kết quả cần đạt: Terminal hiển thị một chuỗi SHA-256 và tên tệp video gốc.

6. Stage 06 - Xem video trước khi giấu tin
ffplay -autoexit media/sample_video.mp4
Kết quả cần đạt: Video gốc mở được, đúng khung hình, không báo lỗi định dạng.

7. Stage 07 - Mở giao diện Jeopardy
python3 gui_nhom8.py
Kết quả cần đạt: Cửa sổ thực hành mở ra với câu chuyện Jeopardy/CTF, bảng so sánh QIM và ST-QIM, các stage thực hiện theo thứ tự.

8. Stage 08 - Thực hiện thử thách CTF trong giao diện
Kết quả cần đạt: Vùng log hiển thị flag CTF, BER/PSNR/SSIM, xác nhận khác biệt giữa QIM và ST-QIM, và trạng thái hoàn thành scoreboard.

9. Stage 09 - Kiểm tra thư mục video sau giấu tin
ls -lh output
Kết quả cần đạt: Terminal hiển thị video sau giấu tin trong thư mục output.

10. Stage 10 - Đọc metadata video sau giấu tin
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate -of default=noprint_wrappers=1 output/jeopardy_stego.mp4
Kết quả cần đạt: Metadata hợp lệ, có codec, độ phân giải và tốc độ khung hình.

11. Stage 11 - Xem video sau giấu tin
ffplay -autoexit output/jeopardy_stego.mp4
Kết quả cần đạt: Video sau nhúng mở được; hình ảnh không vỡ khung, không méo khung hình.

Sau khi hoàn thành, quay về terminal Labtainer VM/host và chạy: checkwork
Dừng lab: stoplab video-stego-qim-jeopardy
