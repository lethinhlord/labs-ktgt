﻿13 - Jeopardy QIM và ST-QIM trong giấu tin video

Huong dan thuc hanh duoc mo bang Firefox trong file guide.html sau khi lab khoi dong.
Nhan Enter khi Labtainer yeu cau de vao lab.
