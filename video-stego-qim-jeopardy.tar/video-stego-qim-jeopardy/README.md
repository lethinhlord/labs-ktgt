13 - Jeopardy QIM và ST-QIM trong giấu tin video

LÝ THUYẾT TÓM TẮT
QIM: Q0(x)=Δ·round(x/Δ); Q1(x)=Δ·round((x-Δ/2)/Δ)+Δ/2; bit tách được chọn theo tập lượng tử gần nhất.
DCT 8×8: ưu tiên hệ số AC thấp-trung bình, tránh hệ số DC F(0,0) để giảm méo cảm nhận.
ST-QIM: z=uᵀx, z'=Qb(z), y=x+(z'-z)u; vector u sinh từ khóa và có ||u||₂=1.

LỆNH LABTAINER
imodule https://github.com/lethinhlord/labs-ktgt/video-stego-qim-jeopardy.tar
labtainer -r video-stego-qim-jeopardy

QUY TRÌNH CHÍNH
1. Xác nhận vị trí làm bài
pwd
Kết quả cần đạt: Terminal hiển thị đường dẫn /home/ubuntu/lab.

2. Liệt kê tệp lab
ls -lh
Kết quả cần đạt: Terminal hiển thị các tệp hướng dẫn, GUI, video và mã thuật toán của bài lab.

3. Kiểm tra video mẫu
ls -lh media/sample_video.mp4
Kết quả cần đạt: Terminal hiển thị tệp media/sample_video.mp4 với dung lượng hợp lệ.

4. Đọc metadata video gốc
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate -of default=noprint_wrappers=1 media/sample_video.mp4
Kết quả cần đạt: Terminal hiển thị codec, độ phân giải và tốc độ khung hình của video gốc.

5. Tính dấu vết video gốc
sha256sum media/sample_video.mp4
Kết quả cần đạt: Terminal hiển thị một chuỗi SHA-256 và tên tệp video gốc.

6. Xem video trước khi giấu tin
xdg-open media/sample_video.mp4 || ffplay -autoexit media/sample_video.mp4
Kết quả cần đạt: Video gốc mở được, đúng khung hình, không báo lỗi định dạng.

7. Mở GUI Jeopardy Nhóm 8
python3 gui_nhom8.py
Kết quả cần đạt: Cửa sổ GUI Nhóm 8 mở ra với câu chuyện Jeopardy/CTF, bảng so sánh QIM và ST-QIM, các nút thực hiện theo thứ tự từ 1 đến 6.

8. Thực hiện thử thách CTF trong GUI
Kết quả cần đạt: Vùng log GUI hiển thị flag CTF, BER/PSNR/SSIM, xác nhận khác biệt giữa QIM và ST-QIM, và trạng thái hoàn thành scoreboard.

9. Kiểm tra thư mục video sau giấu tin
ls -lh output
Kết quả cần đạt: Terminal hiển thị video sau giấu tin trong thư mục output.

10. Đọc metadata video sau giấu tin
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate -of default=noprint_wrappers=1 output/jeopardy_stego.mp4
Kết quả cần đạt: Metadata hợp lệ, có codec, độ phân giải và tốc độ khung hình.

11. Xem video sau giấu tin
xdg-open output/jeopardy_stego.mp4 || ffplay -autoexit output/jeopardy_stego.mp4
Kết quả cần đạt: Video sau nhúng mở được; hình ảnh không vỡ khung, không méo khung hình.

Sau khi hoàn thành, quay về terminal Labtainer VM/host và chạy: checkwork
Dừng lab: stoplab video-stego-qim-jeopardy
