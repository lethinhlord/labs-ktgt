﻿13 - Jeopardy QIM và ST-QIM trong giấu tin video

Huong dan chi tiet duoc mo bang Firefox trong file guide.html khi lab khoi dong.
Nhan Enter de vao lab.
