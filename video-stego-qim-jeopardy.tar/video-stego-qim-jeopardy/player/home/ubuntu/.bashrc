cd /home/ubuntu/lab
if [ -f guide.html ] && [ -z "${QIM_GUIDE_SHOWN:-}" ]; then
  export QIM_GUIDE_SHOWN=1
  python3 show_guide.py >/tmp/qim_guide_open.log 2>&1 || true
fi
if [ -f NOTE.txt ] && [ -z "${QIM_NOTE_SHOWN:-}" ]; then
  export QIM_NOTE_SHOWN=1
  cat NOTE.txt
fi
if [ -f gui_nhom8.py ] && [ -z "${QIM_GUI_SHOWN:-}" ] && [ -n "${DISPLAY:-}" ]; then
  export QIM_GUI_SHOWN=1
  (python3 gui_nhom8.py >/tmp/qim_gui.log 2>&1 &) || true
fi
