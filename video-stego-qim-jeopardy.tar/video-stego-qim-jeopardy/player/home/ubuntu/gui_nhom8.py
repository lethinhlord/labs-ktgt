#!/usr/bin/env python3
from __future__ import annotations
import subprocess, sys, threading, tkinter as tk
from pathlib import Path
from tkinter import ttk

SCRIPT = Path(__file__).with_name("jeopardy_lab.py")
MODE = "jeopardy"
ROOT = Path(__file__).parent

def append(out, text):
    out.insert("end", text)
    out.see("end")

def run_step(args, out, status, label):
    def worker():
        status.set("Đang chạy: " + label)
        append(out, "\n=== " + label + " ===\n")
        try:
            p = subprocess.run(args, cwd=str(ROOT), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
            append(out, p.stdout + "\n")
            status.set("Hoàn thành: " + label if p.returncode == 0 else "Cần kiểm tra lại: " + label)
        except subprocess.TimeoutExpired:
            append(out, "Tiến trình đang chạy lâu. Nếu đây là máy chủ chia sẻ của attacker, hãy giữ cửa sổ này mở.\n")
            status.set("Tiến trình nền đang chạy")
        except Exception as exc:
            append(out, f"Lỗi GUI: {exc}\n")
            status.set("Lỗi: " + label)
    threading.Thread(target=worker, daemon=True).start()

def run_server(out, status):
    append(out, "\n=== Attacker mở dịch vụ chia sẻ gói stego ===\n")
    try:
        subprocess.Popen([sys.executable, str(SCRIPT), "serve"], cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        append(out, "Máy chủ attacker đã được khởi chạy nền tại cổng 8080. Giữ lab mở để defender tải gói.\n")
        status.set("Attacker server: 0.0.0.0:8080")
    except Exception as exc:
        append(out, f"Không mở được dịch vụ attacker: {exc}\n")
        status.set("Lỗi mở attacker server")

def open_path(path, out):
    p = ROOT / path
    if not p.exists():
        append(out, f"Chưa có file để xem: {p}\n")
        return
    try:
        subprocess.Popen(["xdg-open", str(p)])
    except Exception:
        subprocess.Popen(["ffplay", "-autoexit", str(p)])

def card(parent, title, body):
    frame = ttk.Frame(parent, padding=10)
    ttk.Label(frame, text=title, font=("Arial", 11, "bold")).pack(anchor="w")
    ttk.Label(frame, text=body, wraplength=330, justify="left").pack(anchor="w", pady=(4, 0))
    return frame

def main():
    root = tk.Tk()
    root.title("Nhóm 8")
    root.geometry("1120x720")
    root.configure(bg="#eef3f8")
    style = ttk.Style()
    try: style.theme_use("clam")
    except tk.TclError: pass
    style.configure("TButton", padding=8, font=("Arial", 10, "bold"))
    style.configure("TLabel", background="#eef3f8", font=("Arial", 10))
    style.configure("TLabelframe.Label", font=("Arial", 11, "bold"))
    status = tk.StringVar(value="Sẵn sàng")
    title = "Nhóm 8 - Jeopardy QIM/ST-QIM" if MODE == "jeopardy" else "Nhóm 8 - Attack&Defend QIM/ST-QIM"
    ttk.Label(root, text=title, font=("Arial", 20, "bold")).pack(pady=(16, 4))
    story = ("Nhiệm vụ CTF: giải lần lượt 3 thử thách, mở khóa flag và dựng video stego để so sánh."
             if MODE == "jeopardy" else
             "Mô hình chuyên nghiệp: attacker tạo video stego, defender nhận qua mạng nội bộ, kiểm tra toàn vẹn và xác nhận QIM/ST-QIM.")
    ttk.Label(root, text=story, wraplength=980, justify="center").pack(pady=(0, 12))
    top = ttk.Frame(root); top.pack(fill="x", padx=18)
    left = ttk.LabelFrame(top, text="Bảng thuật toán", padding=8); left.pack(side="left", fill="both", expand=True, padx=(0, 8))
    right = ttk.LabelFrame(top, text="Quy trình GUI", padding=8); right.pack(side="left", fill="both", expand=True, padx=(8, 0))
    card(left, "QIM", "Nhúng bit bằng hai coset lượng tử Λ0/Λ1 trên hệ số scalar hoặc hệ số DCT. Dễ quan sát, dung lượng tốt, phụ thuộc Δ.").pack(fill="x", pady=4)
    card(left, "ST-QIM", "Chiếu vector hệ số lên vector trải sinh từ khóa, lượng tử hóa phép chiếu rồi phân bố sai lệch lên toàn vector. Bền hơn trước nhiễu nhỏ và kiểm tra được vai trò khóa.").pack(fill="x", pady=4)
    out = tk.Text(root, wrap="word", bg="#111827", fg="#e5e7eb", insertbackground="#e5e7eb", font=("Consolas", 10), height=18)
    out.pack(fill="both", expand=True, padx=18, pady=12)
    def add(label, cmd, text):
        ttk.Button(right, text=label, command=lambda: run_step([sys.executable, str(SCRIPT), *cmd], out, status, text)).pack(fill="x", pady=3)
    if MODE == "jeopardy":
        add("1. Kiểm tra video", ["probe"], "Kiểm tra video mẫu")
        add("2. CTF QIM scalar", ["challenge1"], "Thử thách QIM vô hướng")
        add("3. CTF DCT-QIM", ["challenge2"], "Thử thách DCT-QIM")
        add("4. CTF ST-QIM khóa", ["challenge3"], "Thử thách ST-QIM có khóa")
        add("5. Dựng video stego", ["render"], "Tạo video sau khi giấu tin")
        add("6. Bảng điểm", ["scoreboard"], "Tổng hợp Jeopardy scoreboard")
        ttk.Button(right, text="Xem video gốc", command=lambda: open_path("media/sample_video.mp4", out)).pack(fill="x", pady=3)
        ttk.Button(right, text="Xem video sau giấu", command=lambda: open_path("output/jeopardy_stego.mp4", out)).pack(fill="x", pady=3)
    else:
        add("1. Kiểm tra video", ["probe"], "Kiểm tra video mẫu")
        add("2. Attacker tạo gói", ["attack"], "Attacker tạo video stego QIM/ST-QIM")
        ttk.Button(right, text="3. Attacker mở server", command=lambda: run_server(out, status)).pack(fill="x", pady=3)
        add("4. Defender nhận gói", ["defend"], "Defender tải và phân tích gói")
        add("5. Defender so sánh", ["compare"], "Tổng hợp kết quả phòng thủ")
        ttk.Button(right, text="Xem video gốc", command=lambda: open_path("media/sample_video.mp4", out)).pack(fill="x", pady=3)
        ttk.Button(right, text="Xem video attacker", command=lambda: open_path("output/attack_video.mp4", out)).pack(fill="x", pady=3)
        ttk.Button(right, text="Xem video defender nhận", command=lambda: open_path("incoming/attack_video.mp4", out)).pack(fill="x", pady=3)
    ttk.Label(root, textvariable=status, font=("Arial", 10, "bold")).pack(anchor="w", padx=18, pady=(0, 10))
    append(out, "GUI đã sẵn sàng. Làm tuần tự từ nút 1 xuống dưới; mỗi nút hiển thị kết quả thuật toán ngay tại vùng log.\n")
    root.mainloop()

if __name__ == "__main__":
    main()
