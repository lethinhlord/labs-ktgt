#!/usr/bin/env python3
from __future__ import annotations
import subprocess, sys, threading, tkinter as tk
from pathlib import Path
from tkinter import ttk

SCRIPT = Path(__file__).with_name("jeopardy_lab.py")
MODE = "jeopardy"

def run(args, out):
    def worker():
        out.insert("end", "$ " + " ".join(args) + "\n")
        out.see("end")
        try:
            p = subprocess.run(args, cwd=str(Path(__file__).parent), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
            out.insert("end", p.stdout + "\n")
        except subprocess.TimeoutExpired:
            out.insert("end", "Lệnh chạy lâu hơn 120 giây. Với lệnh serve, hãy dùng terminal attacker riêng.\n")
        except Exception as exc:
            out.insert("end", f"Lỗi GUI: {exc}\n")
        out.see("end")
    threading.Thread(target=worker, daemon=True).start()

def main():
    root = tk.Tk()
    root.title("Nhóm 8")
    root.geometry("920x620")
    root.configure(bg="#f4f7fb")
    style = ttk.Style()
    try: style.theme_use("clam")
    except tk.TclError: pass
    style.configure("TButton", padding=8, font=("Arial", 10, "bold"))
    style.configure("TLabel", background="#f4f7fb")
    ttk.Label(root, text="Nhóm 8 - GUI QIM/ST-QIM video", font=("Arial", 18, "bold")).pack(pady=(18, 6))
    ttk.Label(root, text="Mô phỏng thuật toán, xem log và so sánh video trước/sau khi giấu tin.").pack(pady=(0, 12))
    bar = ttk.Frame(root); bar.pack(fill="x", padx=18)
    out = tk.Text(root, wrap="word", bg="#111827", fg="#e5e7eb", insertbackground="#e5e7eb", font=("Consolas", 10))
    out.pack(fill="both", expand=True, padx=18, pady=14)
    def add(label, cmd):
        ttk.Button(bar, text=label, command=lambda: run([sys.executable, str(SCRIPT), *cmd], out)).pack(side="left", padx=4, pady=4)
    if MODE == "jeopardy":
        for label, cmd in [("Probe", ["probe"]), ("C1 QIM", ["challenge1"]), ("C2 DCT-QIM", ["challenge2"]), ("C3 ST-QIM", ["challenge3"]), ("Render", ["render"]), ("Scoreboard", ["scoreboard"])]:
            add(label, cmd)
    else:
        for label, cmd in [("Probe", ["probe"]), ("Attack", ["attack"]), ("Defend", ["defend"]), ("Compare", ["compare"])]:
            add(label, cmd)
    ttk.Button(bar, text="Xem video gốc", command=lambda: subprocess.Popen(["xdg-open", str(Path(__file__).parent / "media" / "sample_video.mp4")])).pack(side="left", padx=4, pady=4)
    root.mainloop()

if __name__ == "__main__":
    main()
