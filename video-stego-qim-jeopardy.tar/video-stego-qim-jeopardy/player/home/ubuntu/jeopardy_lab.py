#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
import run_lab as q

LAB_ID = "video-stego-qim-jeopardy"
WORK = Path("work")
OUT = Path("output")

def flag(label, ok):
    h = hashlib.sha256((LAB_ID + "|" + label + "|nhom8").encode()).hexdigest()[:12].upper()
    return f"FLAG{{{label}_{h}}}" if ok else "FLAG{UNSOLVED}"

def save(name, data):
    WORK.mkdir(exist_ok=True)
    (WORK / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def probe():
    info = q.video_probe()
    save("probe.json", info)
    print(json.dumps(info, ensure_ascii=False, indent=2))
    return info

def challenge1():
    bits = q.bits_from_text("Q8")
    values = [17.25 + 4.3 * i for i in range(len(bits))]
    marked = [q.qim_embed(v, b, 12) for v, b in zip(values, bits)]
    attacked = [v + (0.8 if i % 2 else -0.6) for i, v in enumerate(marked)]
    recovered = [q.qim_extract(v, 12) for v in attacked]
    ok = recovered == bits
    data = {"challenge": 1, "method": "scalar QIM", "delta": 12, "ber": q.bit_error_rate(bits, recovered), "solved": ok, "flag": flag("QIM_SCALAR", ok)}
    save("challenge1.json", data)
    print("Challenge 1 - Scalar QIM solved:", ok)
    print(data["flag"])
    return data

def challenge2():
    frame = q.load_video_frame(32, 32)
    bits = q.bits_from_text("D")
    wm, written = q.embed_bits_in_frame(frame, bits, q.LOW_COEFFS, 36, st=False, key="jeopardy-qim")
    recovered = q.extract_bits_from_frame(wm, len(bits), q.LOW_COEFFS, 36, st=False, key="jeopardy-qim")
    ok = recovered == bits and q.psnr(frame, wm) >= 34
    data = {"challenge": 2, "method": "DCT-QIM", "written_bits": written, "psnr": round(q.psnr(frame, wm), 3), "ssim": round(q.ssim_simple(frame, wm), 5), "ber": q.bit_error_rate(bits, recovered), "solved": ok, "flag": flag("DCT_QIM", ok)}
    save("challenge2.json", data)
    print("Challenge 2 - DCT QIM solved:", ok)
    print(data["flag"])
    return data

def challenge3():
    frame = q.load_video_frame(32, 32)
    bits = q.bits_from_text("S")
    wm, written = q.embed_bits_in_frame(frame, bits, q.MID_COEFFS, 44, st=True, key="jeopardy-stqim")
    good = q.extract_bits_from_frame(wm, len(bits), q.MID_COEFFS, 44, st=True, key="jeopardy-stqim")
    bad = q.extract_bits_from_frame(wm, len(bits), q.MID_COEFFS, 44, st=True, key="wrong-key")
    ok = good == bits and q.bit_error_rate(bits, bad) >= 0.25
    data = {"challenge": 3, "method": "keyed ST-QIM", "written_bits": written, "correct_key_ber": q.bit_error_rate(bits, good), "wrong_key_ber": q.bit_error_rate(bits, bad), "solved": ok, "flag": flag("STQIM_KEYED", ok)}
    save("challenge3.json", data)
    print("Challenge 3 - keyed ST-QIM solved:", ok)
    print(data["flag"])
    return data

def render():
    OUT.mkdir(exist_ok=True)
    frames = q.load_video_frames(128, 72, 24)
    bits = q.packet_bits("NHOM8-JEOPARDY-QIM-STQIM")
    marked = []
    for i, frame in enumerate(frames):
        st = i % 2 == 1
        coeffs = q.MID_COEFFS if st else q.LOW_COEFFS
        wm, _ = q.embed_bits_in_frame(frame, bits[i::len(frames)][:64] or bits[:1], coeffs, 42 if st else 32, st=st, key="render-key")
        marked.append(wm)
    raw = bytearray()
    for frame in marked:
        for row in frame:
            raw.extend(bytes(row))
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "gray", "-s", "128x72", "-r", "12", "-i", "-", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(OUT / "jeopardy_stego.mp4")]
    q.run_command_capture(cmd, bytes(raw))
    data = {"video": "output/jeopardy_stego.mp4", "frames": len(marked), "uses_qim": True, "uses_stqim": True, "avg_psnr": round(sum(q.psnr(a,b) for a,b in zip(frames, marked))/len(frames), 3), "avg_ssim": round(sum(q.ssim_simple(a,b) for a,b in zip(frames, marked))/len(frames), 5)}
    save("render_report.json", data)
    print("Rendered viewable before/after video for Jeopardy lab")
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return data

def scoreboard():
    c1, c2, c3 = challenge1(), challenge2(), challenge3()
    r = render()
    data = {"lab": LAB_ID, "solved": sum(1 for c in (c1,c2,c3) if c["solved"]), "total": 3, "quality_ok": r["avg_psnr"] >= 30, "all_ok": c1["solved"] and c2["solved"] and c3["solved"] and r["avg_psnr"] >= 30}
    save("scoreboard.json", data)
    print("Jeopardy scoreboard:")
    print(json.dumps(data, ensure_ascii=False, indent=2))

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    {"probe": probe, "challenge1": challenge1, "challenge2": challenge2, "challenge3": challenge3, "render": render, "scoreboard": scoreboard, "all": scoreboard}[cmd]()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
