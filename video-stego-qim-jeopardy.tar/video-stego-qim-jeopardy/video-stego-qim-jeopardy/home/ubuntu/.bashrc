# Labtainer interactive shell setup. Keep terminal clean; guide opens in Firefox.
export PS1='video-stego-qim-jeopardy@student:\w\$ '
export LAB_NAME='video-stego-qim-jeopardy'
mkdir -p /home/ubuntu/.local/result /home/ubuntu/.local/bin /home/ubuntu/.local/zip /home/ubuntu/.local/instr_config /home/ubuntu/.local/config 2>/dev/null || true
chmod -R u+rwX /home/ubuntu/.local 2>/dev/null || true
cd /home/ubuntu/lab 2>/dev/null || cd /home/ubuntu
if [ -f /home/ubuntu/lab/guide.html ] && [ -z "${QIM_GUIDE_SHOWN:-}" ]; then
  export QIM_GUIDE_SHOWN=1
  if command -v python3 >/dev/null 2>&1; then
    (python3 /home/ubuntu/lab/show_guide.py >/dev/null 2>&1 &)
  fi
fi
